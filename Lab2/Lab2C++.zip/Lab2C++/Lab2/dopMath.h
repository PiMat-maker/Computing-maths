#pragma once
double countPlus(double x, double y);
double countMinus(double x, double y);
double countMultiply(double x, double y);
double countDivision(double x, double y);
double countPower(double x, double y);
double countLog(double x);
double countSin(double x);
double countCos(double x);
double countTg(double x);
double countCtg(double x);