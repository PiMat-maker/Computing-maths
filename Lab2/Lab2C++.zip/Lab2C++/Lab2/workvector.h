#include <string>
#include <vector>
using namespace std;
#pragma once
bool trySetElement(string value, void* elem, char type);
void setVector(vector<vector<double>> &matrix, int size);
void initializeVector(vector<vector<double>> &matrix);